﻿namespace FastFood.Web.ViewModel.Items
{
    public class CreateItemViewModel
    {
        public int CategoryId { get; set; }
        public string CategoryName { get; set; } = null!;
    }
}
