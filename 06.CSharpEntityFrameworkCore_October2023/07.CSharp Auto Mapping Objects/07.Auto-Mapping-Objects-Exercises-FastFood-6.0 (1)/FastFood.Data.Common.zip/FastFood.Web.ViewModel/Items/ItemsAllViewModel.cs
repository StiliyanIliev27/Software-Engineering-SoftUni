﻿namespace FastFood.Web.ViewModel.Items
{
    public class ItemsAllViewModel
    {
        public string Name { get; set; } = null!;

        public decimal Price { get; set; }

        public string Category { get; set; } = null!;
    }
}
