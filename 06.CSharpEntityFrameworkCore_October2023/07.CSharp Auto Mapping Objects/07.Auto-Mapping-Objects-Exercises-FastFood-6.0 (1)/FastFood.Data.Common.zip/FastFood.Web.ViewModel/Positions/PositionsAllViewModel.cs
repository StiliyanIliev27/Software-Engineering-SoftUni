﻿namespace FastFood.Web.ViewModel.Positions
{
    public class PositionsAllViewModel
    {
        public string Name { get; set; } = null!;
    }
}
