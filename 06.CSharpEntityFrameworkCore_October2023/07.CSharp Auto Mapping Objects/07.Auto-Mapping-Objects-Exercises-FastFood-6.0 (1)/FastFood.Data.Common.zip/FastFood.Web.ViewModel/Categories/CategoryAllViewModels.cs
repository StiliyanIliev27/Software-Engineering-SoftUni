﻿namespace FastFood.Web.ViewModel.Categories
{
    public class CategoryAllViewModel
    {
        public string Name { get; set; } = null!;
    }
}
