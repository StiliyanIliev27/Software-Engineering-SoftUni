﻿namespace FastFood.Web.ViewModel.Employees
{
    public class EmployeesAllViewModel
    {
        public string Name { get; set; } = null!;

        public int Age { get; set; }

        public string Address { get; set; } = null!;

        public string Position { get; set; } = null!;
    }
}
