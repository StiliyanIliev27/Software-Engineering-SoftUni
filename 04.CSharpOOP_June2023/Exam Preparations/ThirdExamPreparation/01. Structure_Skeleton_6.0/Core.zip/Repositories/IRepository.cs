﻿namespace UniversityCompetition.Repositories
{
    public interface IRepository
    {
    }
}